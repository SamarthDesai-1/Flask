function authenticate() {
    alert("Please retype email and password ??")
}